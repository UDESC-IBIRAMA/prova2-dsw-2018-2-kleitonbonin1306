import React, { Component } from 'react';
import Header from "./Header";

class Relogio extends Component {

    constructor(props) {
        super(props);
        this.state = {horario: new Date()};
    }
    componenteD() {
        this.timerID = setInterval(
            () =>this.atualiza(),
            1000
        );
    }
    componenteW() {
        clearInterval(this.timerID);
    }
    atualiza() {
        this.setState({
            horario: new Date()
        });
    }
    render() {
        return (
            <div>
                <h2>Hora de brasilia {this.state.horario.toLocaleTimeString()}.</h2>
            </div>
        );
    }
}
export default Header;