import React, { Component } from 'react';
import { Link } from 'react-router-dom'

class Header extends Component {
    render() {
        return (
            <header>
                <nav>
                    <ul>
                        <li><Link exact to='/'>Home</Link></li>
                        <li><Link to='/relogio'>relogio</Link></li>
                        <li><Link to='/formulario'>Formulario</Link></li>
                    </ul>
                </nav>
            </header>
        )
    }
}

export default Header;