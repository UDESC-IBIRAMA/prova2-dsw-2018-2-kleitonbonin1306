import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom'
import Relogio from "./Relogio";
import Formulario from './Formulario';
class Principal extends Component {
    render(){
        return (
            <Switch>
                <Route exact path='/' component={Home} />
                <Route path='/relogio' component={Relogio} />
                <Route path='/formulario' component={Formulario} />

            </Switch>
        )
    }
}
const Home = () => (
    <div>
        <h1>ola mundo!</h1>
    </div>
)
export default Principal;